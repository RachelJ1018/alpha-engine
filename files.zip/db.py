"""
db.py — SQLite schema + helpers
"""
import sqlite3, os

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "alpha.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS news_articles (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    source           TEXT,
    title            TEXT,
    url              TEXT UNIQUE,
    published_at     TEXT,
    content          TEXT,
    fetched_at       TEXT DEFAULT (datetime('now')),
    symbols          TEXT,          -- JSON list e.g. '["NVDA","AMD"]'
    event_type       TEXT,          -- earnings / macro / product / layoff / ma / regulation / ai
    sentiment_score  REAL,          -- -1.0 to 1.0
    novelty_score    REAL,          -- 0-1, is this new info?
    importance_score REAL           -- 0-1
);

CREATE TABLE IF NOT EXISTS price_snapshots (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol        TEXT,
    snapshot_date TEXT,
    close_price   REAL,
    change_pct    REAL,
    volume        REAL,
    avg_volume    REAL,
    volume_ratio  REAL,             -- volume / avg_volume
    rsi_14        REAL,
    ma_20         REAL,
    ma_50         REAL,
    above_ma20    INTEGER,          -- 0 or 1
    week_high_52  REAL,
    week_low_52   REAL,
    market_cap    REAL,
    UNIQUE(symbol, snapshot_date)
);

CREATE TABLE IF NOT EXISTS trade_candidates (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    run_date        TEXT,
    symbol          TEXT,
    company_name    TEXT,
    direction       TEXT,           -- LONG / SHORT / WATCH / AVOID
    final_score     REAL,           -- 0-100
    event_score     REAL,
    sentiment_score REAL,
    technical_score REAL,
    thesis          TEXT,           -- 1-2 sentence core reason
    entry_note      TEXT,           -- specific price/condition
    stop_loss_note  TEXT,
    target_note     TEXT,
    risk_note       TEXT,           -- what would invalidate this
    action          TEXT,           -- BUY_NOW / WAIT / MONITOR / SKIP
    news_ids        TEXT,           -- JSON list of supporting news ids
    UNIQUE(run_date, symbol)
);

CREATE TABLE IF NOT EXISTS watched_symbols (
    symbol   TEXT PRIMARY KEY,
    sector   TEXT,
    priority INTEGER DEFAULT 1,     -- 1=high, 2=medium, 3=low
    enabled  INTEGER DEFAULT 1,
    note     TEXT
);

CREATE TABLE IF NOT EXISTS daily_runs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    run_date    TEXT UNIQUE,
    run_at      TEXT,
    news_fetched INTEGER,
    prices_fetched INTEGER,
    candidates_found INTEGER,
    market_regime TEXT,             -- bull / bear / neutral / choppy
    spy_change_pct REAL,
    summary     TEXT
);
"""

def get_conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    conn.executescript(SCHEMA)
    conn.commit()

    # Seed default watchlist — S&P 500 core + high-vol names
    defaults = [
        ("SPY",  "ETF",           1), ("QQQ",  "ETF",           1),
        ("NVDA", "Technology",    1), ("AMD",  "Technology",    1),
        ("MSFT", "Technology",    1), ("AAPL", "Technology",    1),
        ("GOOGL","Technology",    1), ("META", "Technology",    1),
        ("AMZN", "Technology",    1), ("TSLA", "Automotive",    1),
        ("JPM",  "Finance",       1), ("BAC",  "Finance",       2),
        ("GS",   "Finance",       2), ("PLTR", "Technology",    1),
        ("CRM",  "Technology",    2), ("NFLX", "Media",         2),
        ("UBER", "Technology",    2), ("COIN", "Finance",       2),
        ("SOFI", "Finance",       2), ("ARM",  "Technology",    1),
        ("SMCI", "Technology",    2), ("MU",   "Technology",    2),
        ("AVGO", "Technology",    1), ("TSM",  "Technology",    1),
    ]
    conn.executemany(
        "INSERT OR IGNORE INTO watched_symbols (symbol, sector, priority) VALUES (?,?,?)",
        defaults
    )
    conn.commit()
    conn.close()
    print(f"[db] initialized → {DB_PATH}")

if __name__ == "__main__":
    init_db()
