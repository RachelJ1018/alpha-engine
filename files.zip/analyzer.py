"""
analyzer.py — the brain of the system.
Combines news + price data → scores → trade candidates.
Uses Claude API for final thesis generation.
"""
import json, os, re
from datetime import date, datetime
from modules.db import get_conn

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

# ── Scoring weights ────────────────────────────────────────────────────────
W_SENTIMENT  = 0.30
W_EVENT_TYPE = 0.25
W_TECHNICAL  = 0.25
W_NOVELTY    = 0.10
W_VOLUME     = 0.10

EVENT_IMPORTANCE = {
    "earnings": 1.0, "macro": 0.85, "ma": 0.85, "ai": 0.80,
    "regulation": 0.70, "layoff": 0.65, "product": 0.60, "general": 0.20,
}

def score_technical(price_row) -> float:
    """Return 0-100 technical score."""
    if not price_row:
        return 50.0
    score = 50.0

    rsi = price_row["rsi_14"] or 50
    if 40 <= rsi <= 65:   score += 15   # sweet spot
    elif rsi > 75:        score -= 15   # overbought
    elif rsi < 25:        score += 10   # oversold bounce potential

    vr = price_row["volume_ratio"] or 1.0
    if vr > 2.0:   score += 15   # unusual volume
    elif vr > 1.5: score += 8
    elif vr < 0.5: score -= 10  # low conviction

    if price_row["above_ma20"]: score += 10
    else:                        score -= 5

    chg = price_row["change_pct"] or 0
    if abs(chg) > 5:  score -= 10   # already moved a lot — late?
    elif 1 < chg < 4: score += 8    # healthy move, not overextended

    return round(min(max(score, 0), 100), 1)

def score_news_bundle(articles) -> dict:
    """Aggregate multiple news items into scores."""
    if not articles:
        return {"sentiment": 0.0, "event": 0.2, "novelty": 0.5, "count": 0}

    sentiments   = [a["sentiment_score"] or 0 for a in articles]
    novelties    = [a["novelty_score"] or 0.5 for a in articles]
    importances  = [a["importance_score"] or 0.3 for a in articles]
    event_types  = [a["event_type"] or "general" for a in articles]

    avg_sent  = sum(sentiments) / len(sentiments)
    avg_nov   = sum(novelties) / len(novelties)
    best_event = max(event_types, key=lambda e: EVENT_IMPORTANCE.get(e, 0.2))
    event_score = EVENT_IMPORTANCE.get(best_event, 0.2)

    return {
        "sentiment": round(avg_sent, 2),
        "event": event_score,
        "novelty": round(avg_nov, 2),
        "best_event_type": best_event,
        "count": len(articles),
        "importances": importances,
    }

def compute_final_score(news_scores, tech_score, price_row) -> float:
    """Combine all signals into 0-100 final score."""
    sent_norm  = (news_scores["sentiment"] + 1) / 2      # -1..1 → 0..1
    vol_signal = min((price_row["volume_ratio"] or 1) / 3, 1.0) if price_row else 0.5

    raw = (
        sent_norm              * W_SENTIMENT  * 100 +
        news_scores["event"]   * W_EVENT_TYPE * 100 +
        tech_score             * W_TECHNICAL  +
        news_scores["novelty"] * W_NOVELTY    * 100 +
        vol_signal             * W_VOLUME     * 100
    )
    return round(min(max(raw, 0), 100), 1)

def determine_action(final_score, direction, price_row, regime) -> str:
    """Return concrete action recommendation."""
    chg    = (price_row["change_pct"] or 0) if price_row else 0
    rsi    = (price_row["rsi_14"] or 50) if price_row else 50
    vr     = (price_row["volume_ratio"] or 1) if price_row else 1
    bearish_regime = regime.get("regime") == "bear"

    if direction == "SHORT":
        if final_score >= 65 and not bearish_regime:
            return "WAIT"
        if final_score >= 65 and bearish_regime:
            return "BUY_NOW"  # buy put / short

    if final_score >= 75 and vr >= 1.5 and abs(chg) < 5 and not bearish_regime:
        return "BUY_NOW"
    elif final_score >= 60 and not bearish_regime:
        return "WATCH"
    elif final_score >= 50:
        return "MONITOR"
    else:
        return "SKIP"

def call_claude_for_thesis(symbol, company_name, news_headlines, price_row, news_scores, tech_score, regime) -> dict:
    """
    Call Claude API to generate a specific, high-quality trade thesis.
    Returns dict with thesis, entry_note, stop_loss_note, target_note, risk_note.
    """
    import requests

    if not ANTHROPIC_API_KEY:
        return _rule_based_thesis(symbol, news_headlines, price_row, news_scores)

    price = price_row["close_price"] if price_row else "unknown"
    chg   = price_row["change_pct"] if price_row else 0
    rsi   = price_row["rsi_14"] if price_row else None
    vr    = price_row["volume_ratio"] if price_row else None
    ma20  = price_row["ma_20"] if price_row else None
    ma50  = price_row["ma_50"] if price_row else None

    system = """You are a professional short-term equity trader and researcher.
Your job is to generate specific, actionable daily trade guidance — NOT generic commentary.
Every recommendation must have exact price levels, clear reasoning about TODAY's situation, and a specific invalidation condition.
Return ONLY valid JSON, no markdown.
Schema:
{
  "thesis": "2 sentences max: what happened + why this matters now",
  "entry_note": "specific price level or condition to enter (e.g. 'above $487 on volume > 1.5x avg')",
  "stop_loss_note": "specific stop level and why (e.g. 'below $472, which is the 20-day MA — structural break')",
  "target_note": "specific target and timeframe (e.g. '$510 within 3-5 days, prior resistance')",
  "risk_note": "1 sentence: what single factor would make this trade wrong",
  "direction": "LONG or SHORT",
  "conviction": "HIGH / MEDIUM / LOW"
}"""

    headlines_str = "\n".join(f"- {h}" for h in news_headlines[:5])
    regime_str = regime.get("regime", "neutral").upper()
    spy_chg = regime.get("spy_change", 0)

    user = f"""Generate a specific trade thesis for {symbol} ({company_name}) for TODAY.

MARKET CONTEXT:
- Market regime: {regime_str} (SPY {spy_chg:+.1f}%)

PRICE DATA:
- Current price: ${price}
- Today's change: {chg:+.1f}%
- RSI(14): {rsi}
- Volume ratio (vs avg): {vr}x
- MA20: ${ma20} | MA50: ${ma50}

RECENT NEWS:
{headlines_str}

SIGNAL SCORES:
- News sentiment: {news_scores['sentiment']:+.2f} (-1 to +1)
- Event type: {news_scores.get('best_event_type', 'general')} (importance: {news_scores['event']:.0%})
- Technical score: {tech_score}/100
- News novelty: {news_scores['novelty']:.0%}

Be specific. Use actual price levels. Don't hedge everything. Take a position."""

    try:
        r = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={"Content-Type": "application/json"},
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 500,
                "system": system,
                "messages": [{"role": "user", "content": user}],
            },
            timeout=30,
        )
        d = r.json()
        text = "".join(b["text"] for b in (d.get("content") or []) if b["type"] == "text")
        cleaned = text.replace("```json", "").replace("```", "").strip()
        return json.loads(cleaned)
    except Exception as e:
        print(f"[analyzer] Claude API error for {symbol}: {e}")
        return _rule_based_thesis(symbol, news_headlines, price_row, news_scores)

def _rule_based_thesis(symbol, headlines, price_row, news_scores) -> dict:
    """Fallback thesis without API."""
    sent = news_scores["sentiment"]
    evt  = news_scores.get("best_event_type", "general")
    direction = "LONG" if sent >= 0 else "SHORT"
    price = price_row["close_price"] if price_row else 0
    ma20  = price_row["ma_20"] if price_row else price * 0.97

    top_headline = headlines[0] if headlines else f"{symbol} in focus"
    return {
        "thesis":         f"{top_headline}. Sentiment is {'positive' if sent > 0 else 'negative'} on {evt} catalyst.",
        "entry_note":     f"Entry near ${price:.2f} on confirmation of volume > 1.5x average",
        "stop_loss_note": f"Stop below ${ma20:.2f} (20-day MA)",
        "target_note":    f"Target ${price * 1.05:.2f} (+5%) within 3-5 days",
        "risk_note":      "If market turns risk-off or news reverses, exit immediately.",
        "direction":      direction,
        "conviction":     "MEDIUM",
    }

# ── Main analyzer entry point ─────────────────────────────────────────────
def run_analysis(regime: dict, verbose=True) -> int:
    conn   = get_conn()
    today  = date.today().isoformat()

    symbols = [r["symbol"] for r in conn.execute(
        "SELECT symbol FROM watched_symbols WHERE enabled=1 ORDER BY priority"
    ).fetchall()]

    candidates_created = 0

    for sym in symbols:
        # Get today's price
        price_row = conn.execute(
            "SELECT * FROM price_snapshots WHERE symbol=? AND snapshot_date=?",
            (sym, today)
        ).fetchone()

        # Get recent news (last 48h) mentioning this ticker
        articles = conn.execute("""
            SELECT * FROM news_articles
            WHERE symbols LIKE ?
            AND published_at >= datetime('now', '-48 hours')
            ORDER BY importance_score DESC
            LIMIT 10
        """, (f'%"{sym}"%',)).fetchall()

        # Also get high-importance general macro news
        macro_news = conn.execute("""
            SELECT * FROM news_articles
            WHERE event_type IN ('macro', 'earnings')
            AND published_at >= datetime('now', '-24 hours')
            ORDER BY importance_score DESC
            LIMIT 5
        """).fetchall()

        all_articles = list(articles) + list(macro_news)

        if not price_row and not articles:
            continue  # no data, skip

        news_scores = score_news_bundle(all_articles)
        tech_score  = score_technical(price_row)
        final_score = compute_final_score(news_scores, tech_score, price_row)

        # Only process above threshold to save API calls
        if final_score < 45:
            continue

        # Determine direction
        direction = "LONG" if news_scores["sentiment"] >= 0 else "SHORT"

        action = determine_action(final_score, direction, price_row, regime)

        # Generate specific thesis via Claude
        headlines = [a["title"] for a in articles[:5]]
        # Try to get company name from ticker info
        company_name = sym  # fallback

        thesis_data = call_claude_for_thesis(
            sym, company_name, headlines, price_row, news_scores, tech_score, regime
        )

        direction_final = thesis_data.get("direction", direction)
        news_ids = json.dumps([a["id"] for a in articles[:5]])

        conn.execute("""
            INSERT OR REPLACE INTO trade_candidates
            (run_date, symbol, company_name, direction, final_score,
             event_score, sentiment_score, technical_score,
             thesis, entry_note, stop_loss_note, target_note, risk_note,
             action, news_ids)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            today, sym, company_name, direction_final, final_score,
            round(news_scores["event"] * 100, 1),
            round((news_scores["sentiment"] + 1) / 2 * 100, 1),
            tech_score,
            thesis_data.get("thesis", ""),
            thesis_data.get("entry_note", ""),
            thesis_data.get("stop_loss_note", ""),
            thesis_data.get("target_note", ""),
            thesis_data.get("risk_note", ""),
            action, news_ids,
        ))
        candidates_created += 1

        if verbose:
            print(f"[analyze] {sym:6s} score={final_score:5.1f} action={action} dir={direction_final}")

    conn.commit()
    conn.close()
    return candidates_created
