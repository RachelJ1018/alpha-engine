"""
report_generator.py — generates daily_report.md + HTML
Clean, scannable format. You read this in 10 minutes.
"""
import json
from datetime import date, datetime
from modules.db import get_conn

ACTION_EMOJI = {
    "BUY_NOW": "🟢",
    "WAIT":    "🟡",
    "WATCH":   "🟡",
    "MONITOR": "⚪",
    "SKIP":    "⛔",
}

CONVICTION_EMOJI = {
    "HIGH":   "⬆⬆⬆",
    "MEDIUM": "⬆⬆",
    "LOW":    "⬆",
}

REGIME_DESC = {
    "bull":    "📈 BULL — Broad market rising. Favor longs. Dips tend to be bought.",
    "bear":    "📉 BEAR — Market under pressure. Be cautious with longs. Raise cash.",
    "neutral": "➡ NEUTRAL — Mixed signals. Be selective. Prefer high-conviction setups only.",
    "choppy":  "〰 CHOPPY — Low volume, directionless. Avoid chasing. Wait for clarity.",
    "unknown": "❓ UNKNOWN — No market data yet.",
}

def generate_report(regime: dict, verbose=True) -> str:
    conn  = get_conn()
    today = date.today().isoformat()
    now   = datetime.now().strftime("%Y-%m-%d %H:%M")

    # Pull today's candidates ordered by score
    candidates = conn.execute("""
        SELECT tc.*, ps.close_price, ps.change_pct, ps.rsi_14,
               ps.volume_ratio, ps.ma_20, ps.ma_50
        FROM trade_candidates tc
        LEFT JOIN price_snapshots ps ON tc.symbol = ps.symbol AND ps.snapshot_date = ?
        WHERE tc.run_date = ?
        ORDER BY tc.final_score DESC
        LIMIT 20
    """, (today, today)).fetchall()

    # Pull top news
    top_news = conn.execute("""
        SELECT * FROM news_articles
        WHERE published_at >= datetime('now', '-24 hours')
        ORDER BY importance_score DESC
        LIMIT 10
    """).fetchall()

    spy_chg = regime.get("spy_change", 0)
    regime_label = regime.get("regime", "unknown")

    # ── BUILD MARKDOWN ─────────────────────────────────────────────────────
    lines = []
    lines.append(f"# 📊 Daily Investment Report — {today}")
    lines.append(f"*Generated: {now}*\n")

    # Market context
    lines.append("---")
    lines.append("## 🌍 Market Context\n")
    lines.append(f"**Regime:** {REGIME_DESC.get(regime_label, regime_label)}")
    lines.append(f"**SPY:** {spy_chg:+.2f}%")

    spy_rsi = regime.get("spy_rsi", 50)
    if spy_rsi:
        lines.append(f"**SPY RSI(14):** {spy_rsi}")

    if regime_label == "bear":
        lines.append("\n> ⚠️ **CAUTION:** Market in downtrend. Reduce position sizes. Only highest conviction setups.")
    elif regime_label == "bull":
        lines.append("\n> ✅ **FAVORABLE:** Market trending up. Longs preferred. Manage exits.")
    lines.append("")

    # Action summary
    action_groups = {}
    for c in candidates:
        a = c["action"]
        action_groups.setdefault(a, []).append(c)

    lines.append("---")
    lines.append("## 📋 Today's Action Summary\n")

    buy_now = action_groups.get("BUY_NOW", [])
    watch   = action_groups.get("WATCH", []) + action_groups.get("WAIT", [])
    monitor = action_groups.get("MONITOR", [])

    if buy_now:
        lines.append(f"**🟢 BUY NOW ({len(buy_now)}):** " + " · ".join(f"`{c['symbol']}`" for c in buy_now))
    else:
        lines.append("**🟢 BUY NOW:** None today")

    if watch:
        lines.append(f"**🟡 WATCH ({len(watch)}):** " + " · ".join(f"`{c['symbol']}`" for c in watch))

    if monitor:
        lines.append(f"**⚪ MONITOR ({len(monitor)}):** " + " · ".join(f"`{c['symbol']}`" for c in monitor[:5]))

    lines.append("")

    # ── TRADE IDEAS ──────────────────────────────────────────────────────
    lines.append("---")
    lines.append("## 🎯 Trade Ideas\n")

    actionable = [c for c in candidates if c["action"] in ("BUY_NOW", "WATCH", "WAIT")]
    if not actionable:
        actionable = candidates[:5]

    for i, c in enumerate(actionable[:8], 1):
        sym    = c["symbol"]
        score  = c["final_score"]
        action = c["action"]
        direc  = c["direction"]
        price  = c["close_price"] or 0
        chg    = c["change_pct"] or 0
        rsi    = c["rsi_14"]
        vr     = c["volume_ratio"]
        ma20   = c["ma_20"]

        emoji  = ACTION_EMOJI.get(action, "⚪")
        dir_arrow = "▲" if direc == "LONG" else "▼"

        lines.append(f"### {emoji} #{i} {sym} — {dir_arrow} {direc} | Score: {score:.0f}/100\n")

        # Price snapshot
        lines.append(f"**Price:** ${price:.2f} ({chg:+.1f}%) | "
                     f"**RSI:** {rsi or '—'} | "
                     f"**Vol ratio:** {vr or '—'}x | "
                     f"**vs MA20:** {'above ✅' if price > (ma20 or 0) else 'below ⚠️'}\n")

        # Signal breakdown
        lines.append(f"**Signal Scores:** Event `{c['event_score']:.0f}` | "
                     f"Sentiment `{c['sentiment_score']:.0f}` | "
                     f"Technical `{c['technical_score']:.0f}`\n")

        # Core thesis
        if c["thesis"]:
            lines.append(f"**What & Why:** {c['thesis']}\n")

        # Specific trade plan
        if c["entry_note"]:
            lines.append(f"**Entry:** {c['entry_note']}")
        if c["stop_loss_note"]:
            lines.append(f"**Stop Loss:** {c['stop_loss_note']}")
        if c["target_note"]:
            lines.append(f"**Target:** {c['target_note']}")
        if c["risk_note"]:
            lines.append(f"**Invalidation:** ❌ {c['risk_note']}")

        lines.append("")

    # ── TOP NEWS ─────────────────────────────────────────────────────────
    lines.append("---")
    lines.append("## 📰 Key News (Last 24h)\n")

    for news in top_news[:8]:
        sent  = news["sentiment_score"] or 0
        emoji = "🟢" if sent > 0.1 else "🔴" if sent < -0.1 else "⚪"
        syms  = json.loads(news["symbols"] or "[]")
        tickers_str = " ".join(f"`{s}`" for s in syms[:3])
        lines.append(f"{emoji} **[{news['source']}]** {news['title']}")
        if tickers_str:
            lines.append(f"   *Tickers: {tickers_str}*")
        lines.append(f"   *{news['event_type']} · sentiment: {sent:+.2f}*\n")

    # ── RISK REMINDERS ────────────────────────────────────────────────────
    lines.append("---")
    lines.append("## 🛡 Risk Reminders\n")
    lines.append("- Max position size: **2% of portfolio** per trade")
    lines.append("- Stop loss: **hard exit at -2%** from entry, no exceptions")
    lines.append("- Take profit: target **+5%**, trail stop after +3%")
    lines.append("- Max open positions: **5 at a time**")
    lines.append("- If SPY drops >1.5% intraday: **close all longs, go to cash**")
    lines.append("")

    report_md = "\n".join(lines)

    # Save to file
    import os
    report_dir = os.path.join(os.path.dirname(__file__), "..", "reports")
    os.makedirs(report_dir, exist_ok=True)

    md_path   = os.path.join(report_dir, f"report_{today}.md")
    html_path = os.path.join(report_dir, f"report_{today}.html")
    latest_md = os.path.join(report_dir, "latest.md")

    with open(md_path, "w")   as f: f.write(report_md)
    with open(latest_md, "w") as f: f.write(report_md)

    # Generate HTML version
    html = build_html(report_md, today, regime, actionable, top_news)
    with open(html_path, "w") as f: f.write(html)

    conn.close()
    if verbose:
        print(f"[report] saved → {md_path}")
        print(f"[report] HTML  → {html_path}")
    return report_md


def build_html(md_content, today, regime, candidates, news_items):
    """Build a clean, readable HTML report."""
    regime_label = regime.get("regime", "neutral")
    spy_chg = regime.get("spy_change", 0)
    regime_color = {"bull": "#22c55e", "bear": "#ef4444", "neutral": "#f59e0b", "choppy": "#94a3b8"}.get(regime_label, "#94a3b8")

    cards_html = ""
    for c in candidates[:8]:
        sym    = c["symbol"]
        score  = c["final_score"]
        action = c["action"]
        direc  = c["direction"]
        price  = c["close_price"] or 0
        chg    = c["change_pct"] or 0
        action_color = {"BUY_NOW": "#22c55e", "WATCH": "#f59e0b", "WAIT": "#f59e0b", "MONITOR": "#94a3b8", "SKIP": "#ef4444"}.get(action, "#94a3b8")
        dir_color = "#22c55e" if direc == "LONG" else "#ef4444"

        score_bar = int(score)
        score_color = "#22c55e" if score >= 70 else "#f59e0b" if score >= 50 else "#ef4444"

        cards_html += f"""
<div class="card" style="border-left:3px solid {action_color}">
  <div class="card-header">
    <div>
      <span class="ticker">{sym}</span>
      <span class="action-badge" style="background:{action_color}22;color:{action_color}">{action.replace('_',' ')}</span>
      <span class="dir-badge" style="color:{dir_color}">{"▲ LONG" if direc=="LONG" else "▼ SHORT"}</span>
    </div>
    <div class="score-box">
      <div style="font-size:22px;font-weight:700;color:{score_color}">{score:.0f}</div>
      <div style="font-size:10px;color:#64748b">/ 100</div>
    </div>
  </div>
  <div class="price-row">
    ${price:.2f} <span style="color:{'#22c55e' if chg>=0 else '#ef4444'}">{chg:+.1f}%</span>
    &nbsp;·&nbsp; RSI: {c["rsi_14"] or "—"}
    &nbsp;·&nbsp; Vol: {c["volume_ratio"] or "—"}x
  </div>
  <div class="score-bar-wrap"><div class="score-bar" style="width:{score_bar}%;background:{score_color}"></div></div>

  <div class="section-label">WHAT & WHY</div>
  <div class="thesis">{c["thesis"] or "—"}</div>

  <div class="levels">
    <div class="level-row"><span class="level-label">Entry</span><span class="level-val">{c["entry_note"] or "—"}</span></div>
    <div class="level-row"><span class="level-label">Stop</span><span class="level-val stop">{c["stop_loss_note"] or "—"}</span></div>
    <div class="level-row"><span class="level-label">Target</span><span class="level-val target">{c["target_note"] or "—"}</span></div>
    <div class="level-row"><span class="level-label">❌ If wrong</span><span class="level-val risk">{c["risk_note"] or "—"}</span></div>
  </div>
</div>"""

    news_html = ""
    for n in (news_items or [])[:6]:
        sent = n["sentiment_score"] or 0
        sc = "#22c55e" if sent > 0.1 else "#ef4444" if sent < -0.1 else "#94a3b8"
        syms = json.loads(n["symbols"] or "[]")
        news_html += f"""
<div class="news-item">
  <div style="display:flex;gap:8px;align-items:flex-start">
    <span style="color:{sc};font-size:14px;flex-shrink:0">{"▲" if sent>0.1 else "▼" if sent<-0.1 else "◆"}</span>
    <div>
      <div class="news-title">{n["title"]}</div>
      <div class="news-meta">{n["source"]} · {n["event_type"]} · {sent:+.2f}
        {" · " + " ".join(f'<code>{s}</code>' for s in syms[:3]) if syms else ""}
      </div>
    </div>
  </div>
</div>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Alpha Report — {today}</title>
<style>
  * {{box-sizing:border-box;margin:0;padding:0}}
  body {{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#0b0f1a;color:#e2e8f0;padding:24px;max-width:900px;margin:0 auto;line-height:1.5}}
  h1 {{font-size:22px;font-weight:700;color:#f1f5f9;margin-bottom:4px}}
  h2 {{font-size:14px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:.1em;margin:28px 0 12px}}
  .meta {{font-size:12px;color:#475569;margin-bottom:24px}}
  .regime-bar {{background:#111827;border:.5px solid #1e293b;border-left:3px solid {regime_color};border-radius:6px;padding:12px 16px;margin-bottom:24px;display:flex;justify-content:space-between;align-items:center}}
  .regime-label {{font-size:13px;font-weight:600;color:{regime_color}}}
  .spy-chg {{font-size:20px;font-weight:700;color:{"#22c55e" if spy_chg>=0 else "#ef4444"}}}
  .card {{background:#111827;border:.5px solid #1e293b;border-radius:8px;padding:18px 20px;margin-bottom:12px}}
  .card-header {{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}}
  .ticker {{font-size:20px;font-weight:800;color:#f1f5f9;margin-right:10px;letter-spacing:.04em}}
  .action-badge {{font-size:10px;font-weight:700;padding:3px 8px;border-radius:3px;letter-spacing:.06em;margin-right:6px}}
  .dir-badge {{font-size:12px;font-weight:700}}
  .score-box {{text-align:center}}
  .price-row {{font-size:13px;color:#94a3b8;margin-bottom:8px}}
  .score-bar-wrap {{height:3px;background:#1e293b;border-radius:2px;margin-bottom:14px}}
  .score-bar {{height:3px;border-radius:2px;transition:width .5s}}
  .section-label {{font-size:9px;font-weight:700;color:#475569;letter-spacing:.1em;margin-bottom:5px}}
  .thesis {{font-size:13px;color:#cbd5e1;line-height:1.6;margin-bottom:14px;padding-left:10px;border-left:.5px solid #1e293b}}
  .levels {{display:flex;flex-direction:column;gap:6px}}
  .level-row {{display:flex;gap:12px;font-size:12px;align-items:baseline}}
  .level-label {{color:#475569;min-width:70px;font-size:10px;font-weight:600;letter-spacing:.06em}}
  .level-val {{color:#94a3b8}}
  .level-val.stop {{color:#f87171}}
  .level-val.target {{color:#22c55e}}
  .level-val.risk {{color:#fb923c;font-style:italic}}
  .news-item {{border-bottom:.5px solid #1e293b;padding:10px 0}}
  .news-item:last-child {{border-bottom:none}}
  .news-title {{font-size:13px;color:#cbd5e1;line-height:1.4;margin-bottom:3px}}
  .news-meta {{font-size:11px;color:#475569}}
  .news-meta code {{background:#1e293b;color:#94a3b8;padding:1px 5px;border-radius:2px;font-size:10px}}
  .risk-box {{background:#111827;border:.5px solid #1e293b;border-left:3px solid #ef4444;border-radius:6px;padding:14px 18px}}
  .risk-box li {{font-size:13px;color:#94a3b8;margin-bottom:6px;padding-left:4px}}
</style>
</head>
<body>
<h1>📊 Daily Investment Report</h1>
<div class="meta">Generated: {today} — Alpha Engine Local</div>

<div class="regime-bar">
  <div>
    <div style="font-size:10px;color:#475569;margin-bottom:3px">MARKET REGIME</div>
    <div class="regime-label">{regime_label.upper()}</div>
    <div style="font-size:12px;color:#64748b;margin-top:2px">{REGIME_DESC.get(regime_label,"").split("—")[1].strip() if "—" in REGIME_DESC.get(regime_label,"") else ""}</div>
  </div>
  <div style="text-align:right">
    <div style="font-size:10px;color:#475569;margin-bottom:3px">SPY TODAY</div>
    <div class="spy-chg">{spy_chg:+.2f}%</div>
  </div>
</div>

<h2>🎯 Trade Ideas</h2>
{cards_html}

<h2>📰 Key News</h2>
<div style="background:#111827;border:.5px solid #1e293b;border-radius:8px;padding:14px 18px">
{news_html}
</div>

<h2>🛡 Risk Rules</h2>
<div class="risk-box">
  <ul style="list-style:none;padding:0">
    <li>📌 Max position: <strong>2%</strong> of portfolio per trade</li>
    <li>🔴 Hard stop: <strong>-2%</strong> from entry — no exceptions</li>
    <li>🟢 Take profit: target <strong>+5%</strong>, trail stop after +3%</li>
    <li>⛔ Max open positions: <strong>5</strong></li>
    <li>⚠️ If SPY drops >1.5% intraday: <strong>close all longs, go cash</strong></li>
  </ul>
</div>

<div style="margin-top:24px;font-size:11px;color:#334155;border-top:.5px solid #1e293b;padding-top:16px">
  ⚠ This is a personal research tool, not financial advice. All decisions are your own.
</div>
</body>
</html>"""
