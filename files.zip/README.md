# Alpha Engine — Local Investment Research Tool

Personal daily decision-support system. Runs locally on Mac/PC.
Every day it tells you: **operate / don't operate / how to operate**.

---

## What it does every day

```
[News feeds] → [Price data] → [AI scoring] → [Daily report HTML]
```

1. Pulls news from Yahoo Finance, Reuters, MarketWatch, CNBC, Benzinga
2. Pulls price + technicals (RSI, MA, volume) for your watchlist via yfinance
3. Scores each ticker on: event type, sentiment, technicals, volume, novelty
4. Calls Claude API to write a specific trade thesis with exact entry/stop/target
5. Generates a clean HTML report you open in your browser

---

## Setup (5 minutes)

### 1. Install Python dependencies

```bash
cd alphalocal
pip install -r requirements.txt
```

### 2. Set your Claude API key

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

Add to `~/.zshrc` or `~/.bashrc` so it persists.

### 3. Run once to initialize

```bash
python run_daily.py
```

This creates `data/alpha.db` and opens today's report in your browser.

---

## Daily usage

```bash
# Full run (news + prices + analysis + report)
python run_daily.py

# News only (fast, no price fetch)
python run_daily.py --news-only

# Regenerate report without re-fetching
python run_daily.py --report

# Run silently, don't open browser
python run_daily.py --no-open
```

---

## Automate with cron (Mac)

Run at 7:30am Mon-Fri before market open:

```bash
crontab -e
```

Add:
```
30 7 * * 1-5 cd /path/to/alphalocal && /usr/bin/python3 run_daily.py --no-open >> /tmp/alpha.log 2>&1
```

---

## Customize your watchlist

Edit directly in SQLite:
```bash
sqlite3 data/alpha.db
```
```sql
-- Add a symbol
INSERT INTO watched_symbols (symbol, sector, priority) VALUES ('HOOD', 'Finance', 1);

-- Disable a symbol
UPDATE watched_symbols SET enabled=0 WHERE symbol='BAC';

-- See current watchlist
SELECT * FROM watched_symbols WHERE enabled=1 ORDER BY priority;
```

Or just edit `modules/db.py` → `defaults` list and re-run.

---

## File structure

```
alphalocal/
├── run_daily.py          ← run this every morning
├── requirements.txt
├── data/
│   └── alpha.db          ← SQLite database (auto-created)
├── reports/
│   ├── report_YYYY-MM-DD.html   ← daily HTML reports
│   ├── report_YYYY-MM-DD.md     ← markdown versions
│   └── latest.md                ← always the most recent
└── modules/
    ├── db.py             ← schema + helpers
    ├── news_collector.py ← RSS + scoring
    ├── price_fetcher.py  ← yfinance + technicals
    ├── analyzer.py       ← scoring engine + Claude thesis
    └── report_generator.py ← HTML + markdown output
```

---

## Output: what the report tells you

For each candidate:

| Field | Example |
|-------|---------|
| **Action** | 🟢 BUY NOW / 🟡 WATCH / ⚪ MONITOR |
| **Score** | 78/100 |
| **What & Why** | "NVDA beat earnings by 18% with strong data center guidance. Market hasn't fully priced the forward revision." |
| **Entry** | "Above $487 on volume > 1.5x avg" |
| **Stop Loss** | "Below $472 — breaks 20-day MA" |
| **Target** | "$510 in 3-5 days (prior resistance)" |
| **Invalidation** | "If QQQ breaks below 200-day MA, thesis is off." |

---

## Risk rules (enforced in every report)

- Max position size: **2% of portfolio**
- Hard stop loss: **-2% from entry**
- Take profit target: **+5%**, trail after +3%
- Max open positions: **5**
- If SPY drops >1.5% intraday → **go to cash**

---

## Upgrading later

- **Real options data** → add Polygon.io API key → `modules/options_fetcher.py`
- **Reddit/Twitter** → add social sentiment module
- **Robinhood integration** → use `robin_stocks` library to pull your portfolio
- **Streamlit UI** → `streamlit run app.py` for interactive dashboard
- **Backtesting** → extend `analyzer.py` to pull historical events and compare outcomes
- **Email alerts** → add `smtp` send at end of `run_daily.py`

---

## Cost

- **News + prices:** free (RSS feeds + yfinance)
- **Claude API:** ~$0.01–0.05 per daily run (Sonnet, 20–30 tickers analyzed)
- **Total:** essentially free for personal use
